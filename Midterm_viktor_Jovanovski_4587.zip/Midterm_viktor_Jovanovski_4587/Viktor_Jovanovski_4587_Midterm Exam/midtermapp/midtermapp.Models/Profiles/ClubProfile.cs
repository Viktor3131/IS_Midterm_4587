﻿using AutoMapper;
using midtermapp.Data.Entities;
using midtermapp.Models.DTOs;

namespace midtermapp.Models.Profiles
{
    public class ClubProfile : Profile
    {
        public ClubProfile()
        {
            CreateMap<Club, ClubDTO>()
                .ReverseMap();
        }
    }
}