﻿using AutoMapper;
using midtermapp.Data.Entities;
using midtermapp.Models.DTOs;

namespace midtermapp.Models.Profiles
{
    public class PlayerProfile : Profile
    {
        public PlayerProfile()
        {
            CreateMap<Player, PlayerDTO>()
                .ReverseMap();
        }
    }
}
