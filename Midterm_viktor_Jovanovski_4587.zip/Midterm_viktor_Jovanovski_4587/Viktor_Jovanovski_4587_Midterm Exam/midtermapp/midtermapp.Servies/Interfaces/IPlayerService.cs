﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using midtermapp.Data.Entities;
using midtermapp.Models.DTOs;

namespace midtermapp.Service.Interfaces
{
    public interface IPlayerService
    {
        IEnumerable<PlayerDTO> GetPlayer();
        Task<PlayerDTO> GetPlayerById(int id);
        PlayerDTO AddPlayer(PlayerDTO player);
        PlayerDTO UpdatePlayer(PlayerDTO player);
        Task<bool> DeletePlayer(int id);
    }
}