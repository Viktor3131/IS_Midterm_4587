﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using midtermapp.Data.Entities;
using midtermapp.Models.DTOs;

namespace midtermapp.Service.Interfaces
{
    public interface IClubService
    {
        Task<IEnumerable<Club>> GetClubs();
        Task<Club> GetClubById(int id);
        ClubDTO AddClub(ClubDTO club);
        ClubDTO UpdateClub(ClubDTO club);
        Task<bool> DeleteClub(int id);

    }
}
