﻿using System;

namespace midtermapp.Data
{
    public class midtermDataContext
    {
        public object Players;

        public object Clubs { get; set; }
    }
}
